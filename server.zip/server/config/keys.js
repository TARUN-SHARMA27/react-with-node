module.exports = {
	googleClientID:'268322597841-l6kq8mfja9v956bp0hc1m5qjpfma6p22.apps.googleusercontent.com',
	googleClientSecret:'00BxdGHBogSMr5HEBLvXImcz',
	mongoURI:'mongodb+srv://email-dev:U51ntXo5CJPL04o6@cluster0.vcuhz.mongodb.net/tarun-sharma.tarun?retryWrites=true&w=majority',
}
//mongodb+srv://email-dev:<password>@cluster0.vcuhz.mongodb.net/<dbname>?retryWrites=true&w=majority