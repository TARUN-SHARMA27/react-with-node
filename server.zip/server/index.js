const express=require("express");
const mongoose=require("mongoose");
const keys=require("./config/keys");

require("./models/user");
require("./services/passport.js");

const app=express();
require("./routes/authRoutes.js")(app);

mongoose.connect(keys.mongoURI);







const PORT=process.env.PORT || 3000;

app.listen(PORT,function(){
	console.log("server started");
});
